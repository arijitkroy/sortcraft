<p align="center">
    <img src="https://raw.githubusercontent.com/arijitkroy/sortcraft/main/softcraft.png" alt="sortcraft logo" width="480">
</p>

SortCraft is a comprehensive Python package providing an extensive collection of sorting algorithms suitable for educational, research, and benchmarking purposes. All implementations are type-annotated, documented for clarity, and exposed through a clean flat API for easy import and exploration.

Features
--------
- More than twenty sorting algorithms, including classical, integer/distribution, advanced, parallel, and theoretical types.
- All functions have PEP 484 type annotations and rich, standardized docstrings suitable for IDE/hover documentation and Sphinx autodoc.
- Simple import model: `from sortcraft import merge_sort, quick_sort, cycle_sort, ...`.
- Designed for reliability, readability, and educational use cases as well as algorithmic experimentation.

Installation
------------
Install the latest release from PyPI:

    pip install sortcraft

Or, for the latest development version:

    pip install git+https://github.com/arijitkroy/sortcraft

Quick Usage
-----------

    from sortcraft import merge_sort, heap_sort
    data = [5, 2, 9, 1]
    sorted_data = merge_sort(data)  # [1, 2, 5, 9]

Included Algorithms
-------------------

- Classical comparison sorts: bubble_sort, selection_sort, insertion_sort, merge_sort, quick_sort, heap_sort
- Counting/distribution sorts: counting_sort, radix_sort, pigeonhole_sort, flash_sort, bucket_sort
- Advanced or hybrid: shell_sort, comb_sort, cocktail_sort, timsort, bitonic_sort, cycle_sort
- Educational or theoretical: pancake_sort, gnome_sort, stooge_sort, bogo_sort, odd_even_sort

All functions require a sequence of comparable elements and return a new sorted list.

Type Annotations and Docstring Standards
----------------------------------------
- All user-facing APIs are type-annotated (PEP 484/561 compliant via the included py.typed marker).
- Docstrings follow the Google style, suitable for Sphinx autodoc and IDE hover documentation.
- Each algorithm documents its stability, complexity, and typical usage.

License
-------
SortCraft is licensed under the MIT License. See the LICENSE file for details.

Contributing
------------
Contributions by way of issue reports, algorithm additions, or improvements to documentation are welcome. Please open an issue or submit a pull request on GitHub.