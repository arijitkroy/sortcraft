from sortcraft import counting_sort
print(counting_sort([29, 32, 13, 22, 203, 3]))
print(counting_sort(['Hello', 'World', 'String']))